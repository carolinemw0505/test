package com.spring.cloud.feign;

import org.springframework.stereotype.Component;

@Component
public class HelloWordFailure implements HelloWorldService{

	@Override
	public String sayHello() {
		System.out.println("the service which you are requsting is unavalable!");
		return "the service which you are requsting is unavalable!";
	}

}
