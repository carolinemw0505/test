package com.spring.cloud.client.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.cloud.client.dao.thirdAccountDao;
import com.spring.cloud.client.model.thirdAccount;

@Service
public class thirdAccountService implements thirdAccountDao{

	@Autowired
	private thirdAccountDao thirdAccountDao;
	
	@Override
	public int insert(List<thirdAccount> list) {
		return thirdAccountDao.insert(list);
	}

	@Override
	public thirdAccount findByTid(int tid) {
		return thirdAccountDao.findByTid(tid);
	}

	@Override
	public List<thirdAccount> findByThirdAccountName(String name) {
		return thirdAccountDao.findByThirdAccountName(name);
	}
	
}