package com.spring.cloud.client.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.alibaba.druid.pool.DruidDataSourceFactory;

@Configuration
@MapperScan(basePackages="com.spring.cloud.client.dao")
public class thirdAccountConfig{
	
	@Autowired
	Environment env;
	
	
	@Bean
	public DataSource getDataSource(){
		Properties pro=new Properties();
		pro.setProperty("driverClass", env.getProperty("jdbc.driverClassName"));
		pro.setProperty("url", env.getProperty("jdbc.url"));
		pro.setProperty("username",env.getProperty("jdbc.username"));
		pro.setProperty("password",env.getProperty("jdbc.password"));
		try{
			return DruidDataSourceFactory.createDataSource(pro);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource ds) throws Exception{
		SqlSessionFactoryBean sfb=new SqlSessionFactoryBean();
		sfb.setDataSource(ds);
		sfb.setTypeAliasesPackage(env.getProperty("mybatis.typeAliasesPackage"));
		sfb.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(env.getProperty("mybatis.mapperLocations")));
		return sfb.getObject();
	}
}