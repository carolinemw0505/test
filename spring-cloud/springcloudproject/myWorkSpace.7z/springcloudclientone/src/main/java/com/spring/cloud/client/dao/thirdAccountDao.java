package com.spring.cloud.client.dao;

import java.util.List;

import com.spring.cloud.client.model.thirdAccount;

public interface thirdAccountDao{
	int insert(List<thirdAccount> list);
	
	thirdAccount findByTid(int tid);
	
	List<thirdAccount> findByThirdAccountName(String name);
}