package com.spring.cloud.client.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.cloud.client.bo.thirdAccountService;
import com.spring.cloud.client.model.thirdAccount;

@RestController
@RequestMapping(value="/user")
public class thirdAccountController{
	@Autowired
	thirdAccountService thirdAccountService;
	
	@RequestMapping(value="add",method=RequestMethod.POST)
	@ResponseBody
	public int addUser(@RequestBody List<thirdAccount> ul){
		return thirdAccountService.insert(ul);
	}
	
	@RequestMapping(value="queryByTid",method=RequestMethod.GET)
	@ResponseBody
	public thirdAccount queyByTidUser(int tid){
		return thirdAccountService.findByTid(tid);
	}
	
	@RequestMapping(value="queryListByName",method=RequestMethod.GET)
	@ResponseBody
	public List<thirdAccount> queyListByName(String name){
		return thirdAccountService.findByThirdAccountName(name);
	}
}